//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by QR_Image.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_RIGHTVIEW                   130
#define IDD_BOTTOMVIEW                  131
#define IDR_IMAGEMENU                   132
#define IDC_RHAND                       133
#define IDI_PSYTEC                      134
#define IDC_COMBOLEVEL                  1000
#define IDC_COMBOVERSION                1001
#define IDC_STATICVERSION               1002
#define IDC_CHECKAUTOEXTENT             1003
#define IDC_COMBOMASKINGNO              1004
#define IDC_STATICMASKINGNO             1005
#define IDC_EDITMODULESIZE              1006
#define IDC_SPINMODULESIZE              1007
#define IDC_STATICBMPSIZE               1008
#define IDC_BUTTONCOPY                  1009
#define IDC_BUTTONSAVE                  1010
#define IDC_EDITSOURCEDATA              1011
#define IDC_STATICURL                   1020
#define IDC_STATICMAILTO                1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
